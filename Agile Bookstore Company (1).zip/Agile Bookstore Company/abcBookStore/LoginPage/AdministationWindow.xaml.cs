﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Data;
using BookStoreLIB;

namespace BookStoreGUI
{
     /// <summary>
     /// Interaction logic for AdministrationWindow.xaml
     /// </summary>
     public partial class AdministrationWindow : Window
     {
          DataSet dsBookCat;
          DataTable dbtable;
          UserData userData;
          BookOrder bookOrder;
          //int globalUserID = 0;

          public AdministrationWindow()
          {
               //this.dbtable = dbtable;
               InitializeComponent();
          }

          private void Window_Loaded_1(object sender, RoutedEventArgs e)
          {
               BookCatalog bookCat = new BookCatalog();
               dsBookCat = bookCat.GetBookInfo();
               this.DataContext = dsBookCat.Tables["Category"];
               //bookOrder = new BookOrder();
               //userData = new UserData();
               //this.orderListView.ItemsSource = bookOrder.OrderItemList;
          }

          private void ProductsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
          {

          }
     }
}
