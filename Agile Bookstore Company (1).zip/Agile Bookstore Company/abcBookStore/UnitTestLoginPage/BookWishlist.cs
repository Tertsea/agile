﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BookStoreLIB
{
    public class BookWishlist
    {
        DALWishlist dwl = new DALWishlist();

        public String AddBookToWishList(String ISBN, int Uid)
        {    
            if (dwl.addBookToWishlist(ISBN, Uid))
                return "Successfully saved the data";
            else
                return "Something went wrong while trying to save the data";
        }

        public DataSet getWishListBooks(int uid)
        {
            return dwl.getWishListBooks(uid);
        }
    }

}
