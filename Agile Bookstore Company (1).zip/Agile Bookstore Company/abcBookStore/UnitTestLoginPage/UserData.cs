﻿using System;

namespace BookStoreLIB
{
     public class UserData
     {
          public int UserID { set; get; }
          public string LoginName { set; get; }
          public string Password { set; get; }
          public string FullName { set; get; }
          public string Address { set; get; }
          public string PostalCode { set; get; }
          public string City { set; get; }
          public string Province { set; get; }
          public string Country { set; get; }
        public Boolean isManager;

        public Boolean LogIn(string loginName, string passWord)
          {
               var dbUser = new DALUserInfo();
               UserID = dbUser.LogIn(loginName, passWord);
               if (UserID > 0)
               {
                    LoginName = loginName;
                    Password = passWord;
                    FullName = dbUser.DbFullName;
                    if (dbUser.isManager)
                    {
                         isManager = true;
                    }

                    return true;
               }
               else
                    return false;
          }

        public Boolean EditInfo(int userid, string fullName, string password, string address, string postalCode, string city, string province, string country)
        {
            var dbUser = new DALUserInfo();
            int retUserId = dbUser.EditInfo(userid, fullName, password, address, postalCode, city, province, country);
            if (retUserId > 0)
            {
                Password = password;
                Address = address;
                FullName = fullName;
                PostalCode = postalCode;
                City = city;
                Province = province;
                Country = country;
                return true;
            }
            else
                return false;

        }

        public Boolean CreateProfile(String username, String password, String fullname, String address, String postalCode, String city, String province, String country)
        {
            var dbUser = new DALUserInfo();
            int retUserId = dbUser.CreateProfile(username, password, fullname, address, postalCode, city, province, country);
            if (retUserId > 0)
            {
                LoginName = username;
                Password = password;
                FullName = fullname;
                UserID = retUserId;
                Address = address;
                return true;
            }
            else
                return false;
        }

        public Boolean checkUserName (string username)
        {
            var dbUser = new DALUserInfo();
            if (dbUser.validateUserName(username))
                return true;
            else
                return false;
        }

    }
}