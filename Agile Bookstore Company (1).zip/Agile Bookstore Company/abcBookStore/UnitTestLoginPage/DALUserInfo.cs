﻿using System;
using System.Data.SqlClient;
using System.Diagnostics;

namespace BookStoreLIB
{
     class DALUserInfo
     {
          public string DbFullName { get; set; }
          public int userID { get; set; }
          public Boolean isManager;
          public int test; 

        public int LogIn(string UserName, string Password)
        {
            //var conn = new SqlConnection(BookStoreLIB.Properties.Settings.Default.bdConnection);
            var conn = new SqlConnection(BookStoreLIB.Properties.Settings.Default.tfsConnection);
               try
               {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = "Select UserID, FullName, Manager from UserData where "
                         + " UserName = @UserName and Password = @Password";
                    cmd.Parameters.AddWithValue("@UserName", UserName);
                    cmd.Parameters.AddWithValue("@Password", Password);
                    conn.Open();
                    //int userID = (int)cmd.ExecuteScalar();
                    
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                         userID = (int)reader["UserID"];
                         DbFullName = reader["FullName"].ToString();
                         isManager = (bool)reader["Manager"];
                    }

                    reader.Close();

                    if (userID > 0)
                        return userID;
                    else
                        return -1;
               }
               catch (Exception ex)
               {
                    Debug.WriteLine(ex.ToString());
                    return -1;
               }
               finally
               {
                    if (conn.State == System.Data.ConnectionState.Open) ;
                    conn.Close();
               }
          }

        public int EditInfo(int userid, string name, string pwd, string addr, string postalCode, string city, string province, string country)
        {
            //var conn = new SqlConnection(BookStoreLIB.Properties.Settings.Default.bdConnection);
            var conn = new SqlConnection(BookStoreLIB.Properties.Settings.Default.tfsConnection);
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "Update UserData SET "
                     + " FullName = @FullName, Address = @Address, PostalCode = @PostalCode, City = @City, Province = @Province, Country = @Country, Password = @Password"
                     + " where UserID = @UserID";
                cmd.Parameters.AddWithValue("@FullName", name);
                cmd.Parameters.AddWithValue("@Password", pwd);
                cmd.Parameters.AddWithValue("@Address", addr);
                cmd.Parameters.AddWithValue("@PostalCode", postalCode);
                cmd.Parameters.AddWithValue("@City", city);
                cmd.Parameters.AddWithValue("@Province", province);
                cmd.Parameters.AddWithValue("@Country", country);
                cmd.Parameters.AddWithValue("@UserID", userid);

                conn.Open();
                int userID = (int)cmd.ExecuteScalar();

                if (userID > 0)
                    return userID;
                else
                    return -1;
            }

            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
                return -1;
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
        }

        public int CreateProfile(String username, String password, String fullname, String address, String postalCode, String city, String province, String country)
        {
            Boolean manager = false;
            var conn = new SqlConnection(BookStoreLIB.Properties.Settings.Default.tfsConnection);
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "Insert into UserData (UserName, Password, Manager, FullName, Address, PostalCode, City, Province, Country) "
                     + "Values (@UserName, @Password, @Manager, @FullName, @Address, @PostalCode, @City, @Province, @Country)";
                cmd.Parameters.AddWithValue("@UserName", username);
                cmd.Parameters.AddWithValue("@Password", password);
                cmd.Parameters.AddWithValue("@Manager", (bool) manager);
                cmd.Parameters.AddWithValue("@FullName", fullname);
                cmd.Parameters.AddWithValue("@Address", address);
                cmd.Parameters.AddWithValue("@PostalCode", postalCode);
                cmd.Parameters.AddWithValue("@City", city);
                cmd.Parameters.AddWithValue("@Province", province);
                cmd.Parameters.AddWithValue("@Country", country);
                conn.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                int userID = LogIn(username, password);

                if (userID > 0)
                    return userID;
                else
                    return -1;
            }

            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
                return -1;
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
        }

        public Boolean validateUserName(string username)
        {
            var conn = new SqlConnection(BookStoreLIB.Properties.Settings.Default.tfsConnection);
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "Select Count(*) from UserData where "
                     + " UserName = @UserName ";
                cmd.Parameters.AddWithValue("@UserName", username);

                conn.Open();
                int userID = (int)cmd.ExecuteScalar();

                if (userID == 0)
                    return true;
                else
                    return false;
            }

            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
                return false;
            }

            finally
            {
                if (conn.State == System.Data.ConnectionState.Open);
                conn.Close();
            }
        }

        public DALUserInfo()
        {
        }
    }
}
