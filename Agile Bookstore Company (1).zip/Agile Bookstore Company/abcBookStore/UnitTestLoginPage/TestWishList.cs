﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;

namespace BookStoreLIB
{
    [TestClass]
    public class TestWishList
    {
        BookWishlist bw = new BookWishlist();
        int uid;
        String isbn;
        DataSet books;
        DataTable wishListBooks;

        [TestMethod]
        public void TestGetWBooks1()
        {
            uid = 4;
            int expectedCount = 2;

            books = bw.getWishListBooks(4);
            wishListBooks = books.Tables["UsersBooks"];

            Assert.AreEqual(expectedCount, wishListBooks.Rows.Count);
        }
    }
}
