﻿namespace BookStoreLIB
{


     partial class xyBookstoreDBDataSet
     {
          partial class BookDataDataTable
          {
          }
     }
}
